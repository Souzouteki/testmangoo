//var fs = require('fs')

$(document).ready(function () {
 
    document.getElementById("btnAjouterItem").addEventListener("click", function () {
       addItem();
       console.log(btnItem)
    });

})




function addItem () {

    if(document.getElementById("nomArticle").value !="" && document.getElementById("descArticle").value != "" ){

        fs.readFile("./data/item.json" , 'utf-8' , function (error , data){


            if(error) throw error
             var listeItem = JSON.parse(data)
             listeItem.push({
            
                  title : document.getElementById("nomArticle").value , 
                  description : document.getElementById("descArticle").value
            
             })
            
            })

    }

   


}

