


var secListe = [];

$(document).ready(function () {

    loadJSON();
 
    document.getElementById("btnAjouter").addEventListener("click", function () {
       console.log("Aller page ajouter article")
       window.location = "../Mango/ajouter.html";
    });

})





function loadJSON() {
    $.getJSON("./data/item.json", function (json) {
        var listeItem = [];
        for (var us in json) {
            if (json.hasOwnProperty(us)) {
                var item = json[us];
                listeItem.push(
                    {
                        title: item.title,
                        description: item.description
                    })
            }
        }
        secListe = listeItem;
        console.log(listeItem)
        loadVue();
    })
}


function loadVue(){
    console.log("hmm")

    document.getElementById("secArticle").innerHTML = "";
secListe.forEach(article => {

   
    document.getElementById("secArticle").innerHTML +=" <div class='item'><div class='nomItem'> <h2>"+article.title+"</h2></div><div class='descItem'><p>"+article.description+"</p></div></div>" ;
    
    
    
});

}