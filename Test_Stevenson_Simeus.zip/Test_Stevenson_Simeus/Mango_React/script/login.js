var secListe = [];

$(document).ready(function () {

    loadJSON();
    document.getElementById("btnConn").addEventListener("click", function () {
        verifUser();
    });


})


function loadJSON() {
    $.getJSON("./data/user.json", function (json) {
        var listeUser = [];
        for (var us in json) {
            if (json.hasOwnProperty(us)) {
                var item = json[us];
                listeUser.push(
                    {
                        username: item.username,
                        password: item.password
                    })
            }
        }
        secListe = listeUser;
        console.log(listeUser)

    })
}





function verifUser() {
    console.log("yerrrr +" + secListe.length)



    var txt_nom = document.getElementById("userName").value;
    var txt_code = document.getElementById("password").value;
    var usernameTrouve = false;
    var passCorrect = false;

    console.log(txt_nom)


    for (let i = 0; i < secListe.length; i++) {

        if (secListe[i].username == txt_nom) {

            usernameTrouve = true;

            if (secListe[i].password == txt_code) {

                passCorrect = true;
                console.log("Bienvenue " + secListe[i].username)
            }

        }

    }

    if (usernameTrouve == false) {
        document.getElementById("userName").style.borderColor = "red";

    } else {
        document.getElementById("userName").style.borderColor = "black";
    }

    if (passCorrect == false) {

        document.getElementById("password").style.borderColor = "red";

    } else {
        document.getElementById("password").style.borderColor = "black";
    }



}